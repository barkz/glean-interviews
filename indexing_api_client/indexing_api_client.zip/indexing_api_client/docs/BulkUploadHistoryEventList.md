# BulkUploadHistoryEventList

Information about active and recent successful uploads for the datasource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[BulkUploadHistoryEvent]**](BulkUploadHistoryEvent.md) | Information about active and recent successful uploads for the datasource | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


