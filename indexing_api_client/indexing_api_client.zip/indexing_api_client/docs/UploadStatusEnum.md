# UploadStatusEnum

Upload status, enum of NOT\_UPLOADED, UPLOADED, STATUS\_UNKNOWN

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | Upload status, enum of NOT\_UPLOADED, UPLOADED, STATUS\_UNKNOWN |  must be one of ["UPLOADED", "NOT\_UPLOADED", "STATUS\_UNKNOWN", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


