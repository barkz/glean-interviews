# ProcessingHistoryEventList

Information about processing history for the datasource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[ProcessingHistoryEvent]**](ProcessingHistoryEvent.md) | Information about processing history for the datasource | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


